﻿Public Class Form1
    Dim resultado As Double
    Dim juros As Double
    Dim calculos As Calcular
    Private Sub rdbMontante_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbMontante.CheckedChanged
        grade1()
    End Sub
    Private Sub rdbCapital_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbCapital.CheckedChanged
        Me.Width = 328
        grade2()
    End Sub
    Private Sub rdbTempo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbTempo.CheckedChanged
        Me.Width = 328
        grade4()
    End Sub
    Private Sub rdbDesconto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbDesconto.CheckedChanged
        Me.Width = 328
        grade2()
    End Sub
    Private Sub grade1()
        Label1.Text = "Capital"
        Label2.Text = "Tempo"
        Label3.Text = "Taxa de Juros"
    End Sub
    Private Sub grade2()
        Label1.Text = "Montante"
        Label2.Text = "Tempo"
        Label3.Text = "Taxa de Juros"
    End Sub
    Private Sub grade4()
        Label1.Text = "Montante"
        Label2.Text = "Capital"
        Label3.Text = "Taxa de Juros"
    End Sub
    Private Sub btnCalcular_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalcular.Click
        calculos = New Calcular
        If txtValor1.Text = String.Empty Or txtValor2.Text = String.Empty Or txtValor3.Text = String.Empty Then
            Return
        End If
        If rdbMontante.Checked Then
            calculos.Capital = Convert.ToDouble(txtValor1.Text)
            calculos.Tempo = Convert.ToDouble(txtValor2.Text)
            calculos.Taxa = Convert.ToDouble(txtValor3.Text) / 100
            Try
                resultado = Math.Round(Calcular.CalculaMontante(calculos), 2)
                juros = resultado - calculos.Capital
                resultado = String.Format("{0:C}", resultado)
                juros = String.Format("{0:C}", juros)
                lblResultado.Text = "Montante = " & resultado.ToString
                lblJuros.Text = "Juros = " & juros.ToString
                exibeDetalhes(calculos)
            Catch ex As Exception
                MessageBox.Show("Erro  : " & ex.Message)
            End Try
        ElseIf rdbCapital.Checked Then
            calculos.Montante = Convert.ToDouble(txtValor1.Text)
            calculos.Tempo = Convert.ToDouble(txtValor2.Text)
            calculos.Taxa = Convert.ToDouble(txtValor3.Text) / 100
            Try
                resultado = String.Format("{0:C}", Calcular.CalculaCapital(calculos))
                lblResultado.Text = "Capital = " & resultado
                lblJuros.Text = ""
            Catch ex As Exception
                MessageBox.Show("Erro  : " & ex.Message)
            End Try
        ElseIf rdbTempo.Checked Then
            calculos.Montante = Convert.ToDouble(txtValor1.Text)
            calculos.Capital = Convert.ToDouble(txtValor2.Text)
            calculos.Taxa = Convert.ToDouble(txtValor3.Text) / 100
            Try
                resultado = Math.Round(Calcular.CalculaTempo(calculos), 4)
                lblResultado.Text = "Tempo = " & resultado.ToString
                lblJuros.Text = ""
            Catch ex As Exception
                MessageBox.Show("Erro  : " & ex.Message)
            End Try
        ElseIf rdbDesconto.Checked Then
            calculos.Montante = Convert.ToDouble(txtValor1.Text)
            calculos.Tempo = Convert.ToDouble(txtValor2.Text)
            calculos.Taxa = Convert.ToDouble(txtValor3.Text) / 100
            Try
                resultado = String.Format("{0:C}", Calcular.CalculaDescontoRacional(calculos))
                lblResultado.Text = "Valor Atual = " & resultado
                lblJuros.Text = ""
            Catch ex As Exception
                MessageBox.Show("Erro  : " & ex.Message)
            End Try
        End If
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cboUnidadeTempo.SelectedIndex = 0
    End Sub
    Private Sub exibeDetalhes(ByVal calc As Calcular)
        Dim i As Integer
        Me.Width = 480
        listaCalculo.Items.Clear()
        For i = 0 To calc.Tempo
            calculos.Tempo = i
            resultado = Math.Round(Calcular.CalculaMontante(calculos), 2)
            listaCalculo.Items.Add(i & "-" & String.Format("{0:C}", resultado & vbCrLf))
        Next
    End Sub
End Class
