﻿Public Class Calcular

    Private _montante As Double
    Private _capital As Double
    Private _taxa As Double
    Private _tempo As Double
    Sub New()
    End Sub
    Public Property Montante() As Double
        Get
            Return _montante
        End Get
        Set(ByVal value As Double)
            _montante = value
        End Set
    End Property
    Public Property Capital() As Double
        Get
            Return _capital
        End Get
        Set(ByVal value As Double)
            _capital = value
        End Set
    End Property
    Public Property Taxa() As Double
        Get
            Return _taxa
        End Get
        Set(ByVal value As Double)
            _taxa = value
        End Set
    End Property
    Public Property Tempo() As Double
        Get
            Return _tempo
        End Get
        Set(ByVal value As Double)
            _tempo = value
        End Set
    End Property
    Public Shared Function CalculaMontante(ByVal calc As Calcular) As Double
        Dim valor As Double
        Try
            valor = calc.Capital * Math.Pow((1 + calc.Taxa), calc.Tempo)
        Catch ex As Exception
            Throw
        End Try
        Return valor
    End Function
    Public Shared Function CalculaCapital(ByVal calc As Calcular) As Double
        Dim valor As Double
        Try
            valor = calc.Montante / Math.Pow((1 + calc.Taxa), calc.Tempo)
        Catch ex As Exception
            Throw
        End Try
        Return valor
    End Function
    Public Shared Function CalculaTempo(ByVal calc As Calcular) As Double
        Dim valor As Double
        Try
            valor = (Math.Log10(calc.Montante) - Math.Log10(calc.Capital)) / Math.Log10(1 + calc.Taxa)
        Catch ex As Exception
            Throw
        End Try
        Return valor
    End Function
    Public Shared Function CalculaDescontoRacional(ByVal calc As Calcular) As Double
        Dim valor As Double
        Try
            valor = calc.Montante * Math.Pow((1 + calc.Taxa), -calc.Tempo)
        Catch ex As Exception
            Throw
        End Try
        Return valor
    End Function
End Class
