﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rdbDesconto = New System.Windows.Forms.RadioButton
        Me.cboUnidadeTempo = New System.Windows.Forms.ComboBox
        Me.rdbTempo = New System.Windows.Forms.RadioButton
        Me.rdbCapital = New System.Windows.Forms.RadioButton
        Me.rdbMontante = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.btnCalcular = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtValor3 = New System.Windows.Forms.TextBox
        Me.txtValor2 = New System.Windows.Forms.TextBox
        Me.txtValor1 = New System.Windows.Forms.TextBox
        Me.lblResultado = New System.Windows.Forms.Label
        Me.lblJuros = New System.Windows.Forms.Label
        Me.listaCalculo = New System.Windows.Forms.ListBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.rdbDesconto)
        Me.GroupBox1.Controls.Add(Me.cboUnidadeTempo)
        Me.GroupBox1.Controls.Add(Me.rdbTempo)
        Me.GroupBox1.Controls.Add(Me.rdbCapital)
        Me.GroupBox1.Controls.Add(Me.rdbMontante)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(293, 86)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Marque o item que você deseja Calcular"
        '
        'rdbDesconto
        '
        Me.rdbDesconto.AutoSize = True
        Me.rdbDesconto.Location = New System.Drawing.Point(137, 52)
        Me.rdbDesconto.Name = "rdbDesconto"
        Me.rdbDesconto.Size = New System.Drawing.Size(116, 17)
        Me.rdbDesconto.TabIndex = 5
        Me.rdbDesconto.TabStop = True
        Me.rdbDesconto.Text = "Desconto Racional"
        Me.rdbDesconto.UseVisualStyleBackColor = True
        '
        'cboUnidadeTempo
        '
        Me.cboUnidadeTempo.FormattingEnabled = True
        Me.cboUnidadeTempo.Items.AddRange(New Object() {"Mês", "Ano"})
        Me.cboUnidadeTempo.Location = New System.Drawing.Point(201, 25)
        Me.cboUnidadeTempo.Name = "cboUnidadeTempo"
        Me.cboUnidadeTempo.Size = New System.Drawing.Size(69, 21)
        Me.cboUnidadeTempo.TabIndex = 4
        '
        'rdbTempo
        '
        Me.rdbTempo.AutoSize = True
        Me.rdbTempo.Location = New System.Drawing.Point(137, 28)
        Me.rdbTempo.Name = "rdbTempo"
        Me.rdbTempo.Size = New System.Drawing.Size(58, 17)
        Me.rdbTempo.TabIndex = 3
        Me.rdbTempo.TabStop = True
        Me.rdbTempo.Text = "Tempo"
        Me.rdbTempo.UseVisualStyleBackColor = True
        '
        'rdbCapital
        '
        Me.rdbCapital.AutoSize = True
        Me.rdbCapital.Location = New System.Drawing.Point(15, 52)
        Me.rdbCapital.Name = "rdbCapital"
        Me.rdbCapital.Size = New System.Drawing.Size(57, 17)
        Me.rdbCapital.TabIndex = 1
        Me.rdbCapital.TabStop = True
        Me.rdbCapital.Text = "Capital"
        Me.rdbCapital.UseVisualStyleBackColor = True
        '
        'rdbMontante
        '
        Me.rdbMontante.AutoSize = True
        Me.rdbMontante.Location = New System.Drawing.Point(15, 28)
        Me.rdbMontante.Name = "rdbMontante"
        Me.rdbMontante.Size = New System.Drawing.Size(70, 17)
        Me.rdbMontante.TabIndex = 0
        Me.rdbMontante.TabStop = True
        Me.rdbMontante.Text = "Montante"
        Me.rdbMontante.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.btnCalcular)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtValor3)
        Me.GroupBox2.Controls.Add(Me.txtValor2)
        Me.GroupBox2.Controls.Add(Me.txtValor1)
        Me.GroupBox2.Location = New System.Drawing.Point(13, 105)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(292, 179)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Informe os Valores"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(192, 118)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(15, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "%"
        '
        'btnCalcular
        '
        Me.btnCalcular.Location = New System.Drawing.Point(85, 148)
        Me.btnCalcular.Name = "btnCalcular"
        Me.btnCalcular.Size = New System.Drawing.Size(100, 25)
        Me.btnCalcular.TabIndex = 6
        Me.btnCalcular.Text = "Calcular"
        Me.btnCalcular.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 118)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Label3"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Label2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Label1"
        '
        'txtValor3
        '
        Me.txtValor3.Location = New System.Drawing.Point(85, 115)
        Me.txtValor3.Name = "txtValor3"
        Me.txtValor3.Size = New System.Drawing.Size(100, 20)
        Me.txtValor3.TabIndex = 2
        '
        'txtValor2
        '
        Me.txtValor2.Location = New System.Drawing.Point(85, 78)
        Me.txtValor2.Name = "txtValor2"
        Me.txtValor2.Size = New System.Drawing.Size(100, 20)
        Me.txtValor2.TabIndex = 1
        '
        'txtValor1
        '
        Me.txtValor1.Location = New System.Drawing.Point(85, 42)
        Me.txtValor1.Name = "txtValor1"
        Me.txtValor1.Size = New System.Drawing.Size(100, 20)
        Me.txtValor1.TabIndex = 0
        '
        'lblResultado
        '
        Me.lblResultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResultado.ForeColor = System.Drawing.Color.Blue
        Me.lblResultado.Location = New System.Drawing.Point(12, 287)
        Me.lblResultado.Name = "lblResultado"
        Me.lblResultado.Size = New System.Drawing.Size(260, 23)
        Me.lblResultado.TabIndex = 6
        '
        'lblJuros
        '
        Me.lblJuros.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJuros.ForeColor = System.Drawing.Color.Red
        Me.lblJuros.Location = New System.Drawing.Point(12, 310)
        Me.lblJuros.Name = "lblJuros"
        Me.lblJuros.Size = New System.Drawing.Size(260, 23)
        Me.lblJuros.TabIndex = 7
        '
        'listaCalculo
        '
        Me.listaCalculo.FormattingEnabled = True
        Me.listaCalculo.Location = New System.Drawing.Point(320, 12)
        Me.listaCalculo.Name = "listaCalculo"
        Me.listaCalculo.Size = New System.Drawing.Size(136, 277)
        Me.listaCalculo.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(317, 341)
        Me.Controls.Add(Me.listaCalculo)
        Me.Controls.Add(Me.lblJuros)
        Me.Controls.Add(Me.lblResultado)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Juros Compostos"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdbMontante As System.Windows.Forms.RadioButton
    Friend WithEvents rdbTempo As System.Windows.Forms.RadioButton
    Friend WithEvents rdbCapital As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtValor3 As System.Windows.Forms.TextBox
    Friend WithEvents txtValor2 As System.Windows.Forms.TextBox
    Friend WithEvents txtValor1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCalcular As System.Windows.Forms.Button
    Friend WithEvents lblResultado As System.Windows.Forms.Label
    Friend WithEvents cboUnidadeTempo As System.Windows.Forms.ComboBox
    Friend WithEvents lblJuros As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents listaCalculo As System.Windows.Forms.ListBox
    Friend WithEvents rdbDesconto As System.Windows.Forms.RadioButton

End Class
